const express = require("express");
const router = express.Router();
const data = require("../data");
const reviewData = data.reviews;

router.get("/review/:id", async (req, res) => {
  try {
    let reviewId = req.params.id;
    if (typeof reviewId != "string") {
      res.status(400).json({ error: "Must enter a string for reviewId" });
      return;
    }
    if (reviewId.trim().length == 0) {
      res.status(400).json({ error: "ReviewId must not only contain spaces" });
      return;
    }
    let newId = objectID(reviewId);
    if (!objectID.isValid(newId)) {
      res.status(400).json({ error: "Id must be valid" });
      return;
    }
    let review = reviewData.get(reviewId);
    res.json(review);
  } catch (e) {
    res.sendStatus(404).json({ error: "Review not found" });
  }
});

router.post("/review/:id", async (req, res) => {
  const inputReview = req.body;
  // Validate restaurantId
  if (typeof inputReview.restaurantId != "string") {
    res.status(400).json({ error: "Must enter a string for restaurantId" });
  }
  if (restaurantId.trim().length == 0) {
    res
      .status(400)
      .json({ error: "RestaurantId must not only contain spaces" });
  }
  let newId = objectID(restaurantId);
  if (!objectID.isValid(newId)) {
    res.status(400).json({ error: "Id must be valid" });
  }

  // Validate title
  if (typeof title != "string") {
    res.status(400).json({ error: "Must enter a string for title" });
  }
  if (title.trim().length == 0) {
    res.status(400).json({ error: "Title must not only contain spaces" });
  }

  // Validate reviewer
  if (typeof reviewer != "string") {
    res.status(400).json({ error: "Must enter a string for reviewer" });
  }
  if (reviewer.trim().length == 0) {
    res.status(400).json({ error: "Reviewer must not only contain spaces" });
  }

  // Validate rating
  if (typeof rating != "number") {
    res.status(400).json({ error: "Must enter a number for rating" });
  }
  if (rating > 5 || rating < 1) {
    res.status(400).json({ error: "Rating must be between 1 and 5" });
  }

  // Validate date
  if (typeof dateofReview != "string") {
    res.status(400).json({ error: "Must enter a string for the date" });
  }
  const dateSplit = dateofReview.split("");
  for (var i = 0; i < dateSplit.length; i++) {
    if (i == 2 || i == 5) {
      if (dateSplit[i] != "/") {
        res.status(400).json({ error: "Date is invalid" });
      }
    } else if (
      dateofReview.charCodeAt(i) < 48 ||
      dateofReview.charCodeAt(i) > 57
    ) {
      {
        res.status(400).json({ error: "Date is invalid" });
      }
    }
  }
  const today = new Date();
  if (dateofReview.substr(0, 2) != today.getMonth() + 1) {
    {
      res.status(400).json({ error: "Date of review must be current date" });
    }
  }
  if (dateofReview.substr(3, 2) != today.getDate()) {
    {
      res.status(400).json({ error: "Date of review must be current date" });
    }
  }
  if (dateofReview.substr(6, 4) != today.getFullYear()) {
    {
      res.status(400).json({ error: "Date of review must be current date" });
    }
  }

  // Validate review
  if (typeof review != "string") {
    res.status(400).json({ error: "Must enter a string for review" });
  }
  if (review.trim().length == 0) {
    res.status(400).json({ error: "Review must not only contain spaces" });
  }

  try {
    const newReview = reviewData.create();
  } catch (e) {
    return;
  }
});

module.exports = router;
